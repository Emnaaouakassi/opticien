<?php require_once('header.php'); ?>

<?php
if(!isset($_REQUEST['cus'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
    $statement = $pdo->prepare("SHOW TABLE STATUS LIKE 'tbl_stat'");
    $statement->execute();
    $result = $statement->fetchAll();
    foreach($result as $row) {
        $ai_id=$row[10];
    }
    $statement = $pdo->prepare("INSERT INTO tbl_stat (cus,idsurvey,answer) VALUES (?,?,?)");
    $statement->execute(array($_REQUEST['cus'],$_REQUEST['idsurvey'],$_REQUEST['answer']));
   
	}

?>

<?php

	header('location: survey.php');
?>