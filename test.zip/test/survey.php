<?php require_once('header.php'); ?>



<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer'])) {
    header('location: logout.php');
    exit;
} else {
    // If customer is logged in, but admin make him inactive, then force logout this user.
    $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=? AND cust_status=?");
    $statement->execute(array($_SESSION['customer']['cust_id'],0));
    $total = $statement->rowCount();
    if($total) {
        header('location: logout.php');
        exit;
    }
}
?>
	
<div class="page">

    <div class="container">
        <div class="row">            
            <div class="col-md-12"> 
            <?php if($error_message): ?>
			<div class="callout callout-danger">
				<p>
					<?php echo $error_message; ?>
				</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
				<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>
                <?php require_once('customer-sidebar.php'); ?>
            </div>
            <div class="col-md-12">
                <div class="user-content">
                    <h3 class="text-left">
                        Survey
                    </h3>
                    <div class="box-body table-responsive">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Survey Name</th>
								<th>Question</th>
								<th>Answer</th>
								<th width="140">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$i=0;
							$statement = $pdo->prepare("SELECT
														
														ids,
														noms,
														dates,
														questions,
														types
							                           	FROM tbl_survey
							                           	
                                                           ");                             
							$statement->execute();
							$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
							foreach ($result as $row) {
                                $types    = $row['types'];
								$i++;
								?>
								<tr>
                                    <input type=""  class="form-control"  name="idsurveys" value="<?php echo $row['ids']; ?>">
                                    <input type=""  class="form-control"  name="cus" value="22">

									<td><?php echo $row['noms']; ?></td>
									<td><?php echo $row['questions']; ?></td>
                                    <td>
                                    <?php if ($types == 'Boolean'){?>
                                    <select name="answer" class="form-control">
									<option value="YES">YES</option>
									<option value="NO">NO</option>
								    </select>
                                <?php
                                    } 
                                 else {?>
                                    <input type="Number" autocomplete="off" class="form-control" style="size:4;" name="answer" value="">
                                <?php
                                    } 
                                    
                                ?>
                                    </td>
                                    
									
									<td>			
                                    <form method="POST" action="survery-sumbit.php">		
                                    <a href="survey-submit.php?idsurvey=<?php echo $row['ids'];?>&amp;cus=33&amp;answer=33" class="btn btn-primary btn-xs">Submit</a>
										  
									</td>
								</tr>
								<?php
							}
							?>		
                            					
						</tbody>
					</table>
				</div>
			</div>
                </div>                
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>