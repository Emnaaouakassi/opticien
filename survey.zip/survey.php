<?php require_once('header.php'); ?>


<section class="content-header">
	<div class="content-header-left">
		<h1>View Statistics </h1>
	</div>
	<div class="content-header-right">
		<a href="survery-add.php" class="btn btn-primary btn-sm">Add Survey</a>
	</div>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-info">
				<div class="box-body table-responsive">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Id</th>
								<th>Name</th>
								<th>Picture</th>
								<th>Question</th>
								<th>Type Question</th>
								<th width="140">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$i = 0;
							$statement = $pdo->prepare("SELECT
														
														ids,
														noms,
														dates,
														questions,
														types

							                           	FROM tbl_survey
							                           	
							                           	");
							$statement->execute();
							$result = $statement->fetchAll(PDO::FETCH_ASSOC);
							foreach ($result as $row) {
								$i++;
								?>
								<tr>
									<td><?php echo $row['ids']; ?></td>
									<td><?php echo $row['noms']; ?></td>

									<td style="width:150px;"><?php if ($row['dates'] != 'NON') { ?> <img src="../assets/uploads/<?php echo $row['dates']; ?>" style="width:140px;"> <?php } else {
																																															?> No Picture <?php
																																																				} ?></td>
									<td><?php echo $row['questions']; ?></td>
									<td id="abc"><?php echo $row['types']; ?></td>
									<td>
										<a href="survey.php?ids=<?php echo $row['ids']; ?>&amp;types=<?php echo $row['types']; ?>" class="btn  btn-success btn-xs" name="submit">View Results</a>
										<a href="survey-edit.php?ids=<?php echo $row['ids']; ?>" class="btn btn-primary btn-xs">Edit</a>
										<a href="#" class="btn btn-danger btn-xs" data-href="survey-delete.php?ids=<?php echo $row['ids']; ?>" data-toggle="modal" data-target="#confirm-delete">Delete</a>
									</td>
								</tr>
								<?php

									//}
									?>
								<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
											</div>
											<div class="modal-body">
												<p>Are you sure want to delete this item?</p>
												<?php echo $row['types']; ?>



												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
													<a class="btn btn-danger btn-ok">Delete</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php
							}

							?>
				</div>

				</tbody>
				</table>
				<?php

				$i = 0;
				if (isset($_REQUEST['ids'])){
				$ids = $_REQUEST['ids'];
				$statement = $pdo->prepare("SELECT
											distinct
											idsurvey,
											answer
											   FROM tbl_stat
											   where idsurvey = $ids
											   ");
				$statement->execute();
				$result2 = $statement->fetchAll(PDO::FETCH_ASSOC);
				$total = Count($result2);


				$statement = $pdo->prepare("SELECT
				distinct
				idsurvey,
				answer
				   FROM tbl_stat
				   where idsurvey = $ids and answer='NO'
				   ");
				$statement->execute();
				$result3 = $statement->fetchAll(PDO::FETCH_ASSOC);
				$total2 = Count($result3);

				/*foreach ($result2 as $row2) {
					?>
					<td><?php echo $row2['idsurvey']; ?></td>

				<?php
				}*/
				if ($_REQUEST['types'] == "Boolean") {
					?>

					<?php //echo $total; ?>
					<?php //echo $total2; ?>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
						<div class="analytics-rounded res-mg-t-30">
							<div class="analytics-rounded-content">
								<h2>Percentage Sequence</h2>
								<h5><i class="fa fa-circle" style="color: #1ab394;"></i>YES
								<i class="fa fa-circle" style="color: #ed5565;"></i>NO</h5>
								<h3><hspan id="result"><?php echo $total-$total2; ?></span>/<span id="result2"><?php echo $total2; ?></span></h3>
								<div class="text-center">
									<div id="sparkline54"></div>
								</div>
							</div>
						</div>
					</div>
				<?php
				}
			}
				?>
			</div>

		</div>
	</div>
	</div>
</section>

<!-- jquery
		============================================ -->

<script src="js/vendor/jquery-1.11.3.min.js"></script>
<script src="js/sparkline/jquery.sparkline.min.js"></script>
<?php include('js/sparkline/sparkline-active.php'); ?>
<?php require_once('footer.php'); ?>