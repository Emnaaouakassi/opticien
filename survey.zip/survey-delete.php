<?php require_once('header.php'); ?>

<?php
if(!isset($_REQUEST['ids'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
	$statement = $pdo->prepare("SELECT * FROM tbl_survey WHERE ids=?");
	$statement->execute(array($_REQUEST['ids']));
	$total = $statement->rowCount();
	if( $total == 0 ) {
		header('location: logout.php');
		exit;
	}
}
?>

<?php

	// Getting photo ID to unlink from folder
	$statement = $pdo->prepare("SELECT * FROM tbl_survey WHERE ids=?");
	$statement->execute(array($_REQUEST['ids']));
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);							


	// Delete from tbl_survey
	$statement = $pdo->prepare("DELETE FROM tbl_survey WHERE ids=?");
	$statement->execute(array($_REQUEST['ids']));

	header('location: survey.php');
?>